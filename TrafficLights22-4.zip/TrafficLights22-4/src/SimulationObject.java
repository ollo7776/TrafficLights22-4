public abstract class SimulationObject {
    public abstract void update();
}
