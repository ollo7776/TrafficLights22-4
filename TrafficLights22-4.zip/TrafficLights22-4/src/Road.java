public class Road extends SimulationObject {
    @Override
    public String toString(){
        return ".";
    }

    @Override
    public void update(){

    }
}
